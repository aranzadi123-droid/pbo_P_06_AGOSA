# Tugas 2 — Inheritance Pegawai (PHP 8+)

Jalankan melalui XAMPP dengan menaruh folder `Task2_Pegawai` di `htdocs`, lalu buka `http://localhost/Task2_Pegawai/`.

- `Pegawai` adalah parent class yang memiliki ID, nama, gaji pokok, constructor, validasi non-negatif, dan method `hitungGaji()`.
- `PegawaiTetap` dan `PegawaiKontrak` adalah child class yang memanggil `parent::__construct()` dan melakukan override `hitungGaji()`.
- Contoh aturan hitung: pegawai tetap mendapat tunjangan Rp500.000; pegawai kontrak mendapat tunjangan Rp200.000.
- Output menampilkan kedua objek.
