# Jawaban Tugas PBO — Pertemuan 06

## Tugas 1 — Diagram class dan penjelasan

```text
                 Mahasiswa
        # nim, # nama, # prodi, # semester
        + getNim(), + getNama(), + getProdi()
                       △
              ┌────────┴────────┐
              │                 │
      MahasiswaReguler   MahasiswaBeasiswa
      - ukt               - ukt
      + hitungUKT()       - potongan
                          + hitungUKT()
```

Tanda `+` berarti public, `-` private, dan `#` protected. Parent `Mahasiswa` menyimpan atribut umum. `MahasiswaReguler` dan `MahasiswaBeasiswa` mewarisi atribut umum dan menambahkan data biaya masing-masing.

**Private vs protected:** private hanya dapat diakses dari class pemiliknya. Protected dapat diakses dari class pemilik dan class turunannya. Contoh, NIM dapat dibuat private agar tidak diubah langsung, sedangkan nama dapat protected jika memang perlu dipakai child class. Akses tetap sebaiknya melalui getter atau method yang tervalidasi.

## Tugas 2 — Inheritance Pegawai

Lihat folder `Task2_Pegawai`:
- `Pegawai.php`: parent class, constructor, validasi ID/nama dan gaji tidak negatif, serta method `hitungGaji()`.
- `PegawaiTetap.php`: child class, memanggil `parent::__construct()` dan override `hitungGaji()` dengan tunjangan tetap Rp500.000.
- `PegawaiKontrak.php`: child class, memanggil `parent::__construct()` dan override `hitungGaji()` dengan tunjangan kontrak Rp200.000.
- `index.php`: membuat dua object dan menampilkan hasilnya.

Output: Andi (tetap) Rp5.500.000; Budi (kontrak) Rp4.200.000. Nilai tunjangan adalah asumsi contoh untuk demonstrasi.

## Tugas 3 — Pengembangan CRUD Mahasiswa

Lihat folder `Task3_CRUD_Mahasiswa`. Project ini meneruskan Praktikum 05. Pilihan jenis Reguler/Beasiswa ditambahkan beserta UKT dan potongan. Tabel menampilkan jenis, UKT, potongan, dan UKT akhir. Tambah, cari, edit, hapus, session, CSRF, dan NIM yang tidak dapat diubah saat edit tetap dipertahankan.

Rumus:
- Reguler: UKT akhir = UKT.
- Beasiswa: UKT akhir = UKT × (1 − potongan/100).

Validasi: UKT >= 0 dan potongan 0–100. `MahasiswaReguler` serta `MahasiswaBeasiswa` mewarisi `Mahasiswa` dan meng-override `hitungUkt()`.

## Tugas 4 — Inheritance vs komposisi

| Hubungan | Jenis | Alasan |
|---|---|---|
| Mahasiswa–MahasiswaBeasiswa | Inheritance (is-a) | MahasiswaBeasiswa adalah jenis Mahasiswa. |
| Mahasiswa–Alamat | Komposisi (has-a) | Mahasiswa memiliki alamat. |
| Mahasiswa–KartuPerpustakaan | Komposisi (has-a) | Mahasiswa memiliki kartu perpustakaan. |
| Mahasiswa–MahasiswaReguler | Inheritance (is-a) | MahasiswaReguler adalah jenis Mahasiswa. |

Contoh inheritance keliru: `class Alamat extends Mahasiswa` atau `class KartuPerpustakaan extends Mahasiswa`, karena alamat dan kartu bukan jenis mahasiswa. Keduanya lebih tepat menjadi object/property yang dimiliki Mahasiswa.

## Menjalankan dan menguji

Gunakan PHP 8+ / XAMPP. Salin folder `Task2_Pegawai` dan `Task3_CRUD_Mahasiswa` ke `htdocs`, lalu buka masing-masing `http://localhost/Task2_Pegawai/` dan `http://localhost/Task3_CRUD_Mahasiswa/`.

Pengujian CLI untuk Tugas 3:
- `php tests/test_model.php`
- `php tests/test_inheritance.php`

Project memakai PHP Session untuk latihan dan belum memakai database permanen.
